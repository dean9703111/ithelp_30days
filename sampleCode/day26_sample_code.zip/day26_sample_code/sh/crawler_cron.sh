# 進入專案資料夾
cd /Users/d/Documents/external_project/ithelp_30days/day26
# 啟動排程服務
yarn forever