const fs = require('fs');
const readline = require('readline');
const { google } = require('googleapis');
const dateFormat = require('dateformat');
require('dotenv').config() //載入.env環境檔
exports.updateGoogleSheets = updateGoogleSheets;//讓其他程式在引入時可以使用這個函式

// If modifying these scopes, delete token.json.
// 原本的範本是有readonly，這樣只有讀取權限，拿掉後什麼權限都有了
const SCOPES = ['https://www.googleapis.com/auth/spreadsheets'];
// The file token.json stores the user's access and refresh tokens, and is
// created automatically when the authorization flow completes for the first
// time.
const TOKEN_PATH = 'tools/google_sheets/token.json';

/**
 * Create an OAuth2 client with the given credentials, and then execute the
 * given callback function.
 * @param {Object} credentials The authorization client credentials.
 * @param {function} callback The callback to call with the authorized client.
 */
function authorize (credentials, callback) {
  const { client_secret, client_id, redirect_uris } = credentials.installed;
  const oAuth2Client = new google.auth.OAuth2(
    client_id, client_secret, redirect_uris[0]);

  // Check if we have previously stored a token.
  fs.readFile(TOKEN_PATH, (err, token) => {
    if (err) return getNewToken(oAuth2Client, callback);
    oAuth2Client.setCredentials(JSON.parse(token));
    callback(oAuth2Client);
  });
}

/**
 * Get and store new token after prompting for user authorization, and then
 * execute the given callback with the authorized OAuth2 client.
 * @param {google.auth.OAuth2} oAuth2Client The OAuth2 client to get token for.
 * @param {getEventsCallback} callback The callback for the authorized client.
 */
function getNewToken (oAuth2Client, callback) {
  const authUrl = oAuth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
  });
  console.log('Authorize this app by visiting this url:', authUrl);
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  rl.question('Enter the code from that page here: ', (code) => {
    rl.close();
    oAuth2Client.getToken(code, (err, token) => {
      if (err) return console.error('Error while trying to retrieve access token', err);
      oAuth2Client.setCredentials(token);
      // Store the token to disk for later program executions
      fs.writeFile(TOKEN_PATH, JSON.stringify(token), (err) => {
        if (err) return console.error(err);
        console.log('Token stored to', TOKEN_PATH);
      });
      callback(oAuth2Client);
    });
  });
}

async function getSheets (auth) {//取得Google Sheets所有的sheet
  const sheets = google.sheets({ version: 'v4', auth });
  const request = {
    spreadsheetId: process.env.SPREADSHEET_ID,
    includeGridData: false,
  }
  try {
    let response = (await sheets.spreadsheets.get(request)).data;
    const sheets_info = response.sheets
    return sheets_info
  } catch (err) {
    console.error(err);
  }
}

async function addSheet (title, auth) {//新增一個sheet到指定的Google Sheets
  const sheets = google.sheets({ version: 'v4', auth });
  const request = {
    // The ID of the spreadsheet
    "spreadsheetId": process.env.SPREADSHEET_ID,
    "resource": {
      "requests": [{
        "addSheet": {//這個request的任務是addSheet
          // 你想給這個sheet的屬性
          "properties": {
            "title": title,
            "gridProperties": {
              "frozenRowCount": 1,//我將最上面那一列設定為凍結
              "frozenColumnCount": 1//我將最左邊那一欄設定為凍結
            },
          }
        },
      }]
    }
  };
  try {
    const response = (await sheets.spreadsheets.batchUpdate(request)).data;
    const sheetId = response.replies[0].addSheet.properties.sheetId
    console.log('added sheet:' + title)
    return sheetId

  }
  catch (err) {
    console.log('The API returned an error: ' + err);
  }
}

async function getFBIGSheet (auth) {// 取得FB粉專、IG帳號的Sheet資訊
  const sheets = [//我們Google Sheets需要的sheet
    { title: 'FB粉專', id: null },
    { title: 'IG帳號', id: null }
  ]
  const online_sheets = await getSheets(auth)//抓目前存在的sheet

  for (sheet of sheets) {
    online_sheets.forEach(online_sheet => {
      if (sheet.title == online_sheet.properties.title) {// 如果線上已經存在相同的sheet title就直接使用相同id
        sheet.id = online_sheet.properties.sheetId
      }
    })
    if (sheet.id == null) {//如果該sheet尚未被建立，則建立
      console.log(sheet.title + ':not exsit')
      try {
        sheet.id = await addSheet(sheet.title, auth)//如果不存在就會新增該sheet        
      } catch (e) {
        console.error(e)
      }
    }
  }
  return sheets;
}

async function writeSheet (title, sheet_id, result_array, auth) {
  // 取得線上第一欄的粉專名稱
  let online_title_array = await readTitle(title, auth)
  // 如果json檔有新增的粉專就補到最後面
  result_array.forEach(fanpage => {
    if (!online_title_array.includes(`=HYPERLINK("${fanpage.url}","${fanpage.title}")`)) {
      online_title_array.push(`=HYPERLINK("${fanpage.url}","${fanpage.title}")`)
    }
  });

  // "粉專名稱+粉專網址"作為寫入追蹤人數欄位的判斷
  let trace_array = []
  online_title_array.forEach(title => {
    let fanpage = result_array.find(fanpage => `=HYPERLINK("${fanpage.url}","${fanpage.title}")` == title)
    if (fanpage) {
      trace_array.push([fanpage.trace])
    } else {
      trace_array.push([])
    }
  });
  // 抓取當天日期
  const datetime = new Date()

  if (online_title_array[0] !== title) {//如果是全新的sheet就會在開頭插入
    online_title_array.unshift(title)
    trace_array.unshift([dateFormat(datetime, "GMT:yyyy/mm/dd")])
  } else {//如果不是全新就取代
    trace_array[0] = [dateFormat(datetime, "GMT:yyyy/mm/dd")]
  }

  // 寫入粉專名稱
  await writeTitle(title, online_title_array.map(title => [title]), auth)

  // 插入空欄位
  await insertEmptyCol(title, sheet_id, auth)
  // 寫入追蹤人數
  await writeTrace(title, trace_array, auth)
}

async function readTitle (title, auth) {
  const sheets = google.sheets({ version: 'v4', auth });
  const request = {
    spreadsheetId: process.env.SPREADSHEET_ID,
    ranges: [
      `'${title}'!A:A`
    ],
    valueRenderOption: "FORMULA"
  }
  try {
    let title_array = []
    let values = (await sheets.spreadsheets.values.batchGet(request)).data.valueRanges[0].values;
    if (values) {//如果沒資料values會是undefine，所以我們只在有資料時塞入
      title_array = values.map(value => value[0]);
     
    }
    // console.log(title_array)
    return title_array
  } catch (err) {
    console.error(err);
  }
}

async function writeTitle (title, title_array, auth) {//title都是寫入第一欄
  const sheets = google.sheets({ version: 'v4', auth });
  const request = {
    spreadsheetId: process.env.SPREADSHEET_ID,
    valueInputOption: "USER_ENTERED",// INPUT_VALUE_OPTION_UNSPECIFIED|RAW|USER_ENTERED
    range: [
      `'${title}'!A:A`
    ],
    resource: {
      values: title_array
    }
  }
  try {
    await sheets.spreadsheets.values.update(request);
    console.log(`updated ${title} title`);
  } catch (err) {
    console.error(err);
  }
}


async function writeTrace (title, trace_array, auth) {//填入追蹤者人數
  const sheets = google.sheets({ version: 'v4', auth });
  const request = {
    spreadsheetId: process.env.SPREADSHEET_ID,
    valueInputOption: "USER_ENTERED",// INPUT_VALUE_OPTION_UNSPECIFIED|RAW|USER_ENTERED
    range: [
      `'${title}'!B:B`
    ],
    resource: {
      values: trace_array
    }
  }
  try {
    await sheets.spreadsheets.values.update(request);
    console.log(`updated ${title} trace`);
  } catch (err) {
    console.error(err);
  }
}

async function insertEmptyCol (title, sheet_id, auth) {//插入空白欄位
  const sheets = google.sheets({ version: 'v4', auth });
  const request = {
    // The ID of the spreadsheet
    "spreadsheetId": process.env.SPREADSHEET_ID,
    "resource": {
      "requests": [{
        "insertDimension": {//插入新欄位
          "range": {
            "sheetId": sheet_id,
            "dimension": "COLUMNS",
            "startIndex": 1,//代表插入範圍從第一欄開始到第二欄結束
            "endIndex": 2
          },
          "inheritFromBefore": true
        }
      },
      {
        "updateDimensionProperties": {//這裡是為了修正欄寬
          "range": {
            "sheetId": sheet_id,
            "dimension": "COLUMNS",
            "startIndex": 1,
            "endIndex": 2//只需要首欄
          },
          "properties": {
            "pixelSize": 85
          },
          "fields": "pixelSize"
        }
      }]
    }
  };
  try {
    await sheets.spreadsheets.batchUpdate(request)
    console.log('update sheet:' + title + ' new column')
  }
  catch (err) {
    console.log('The API returned an error: ' + err);
  }
}

function getAuth () {
  return new Promise((resolve, reject) => {
    try {
      const content = JSON.parse(fs.readFileSync('tools/google_sheets/credentials.json'))
      authorize(content, auth => {
        resolve(auth)
      })
    } catch (err) {
      console.error('憑證錯誤');
      reject(err)
    }
  })
}
async function updateGoogleSheets (ig_result_array, fb_result_array) {
  try {
    const auth = await getAuth()
    const sheets = await getFBIGSheet(auth)//取得線上FB、IG的sheet資訊
    for (sheet of sheets) {
      if (sheet.title === 'FB粉專') {
        await writeSheet(sheet.title, sheet.id, fb_result_array, auth)
      } else if (sheet.title === 'IG帳號') {
        await writeSheet(sheet.title, sheet.id, ig_result_array, auth)
      }
    }
    console.log(`成功更新Google Sheets：https://docs.google.com/spreadsheets/d/${process.env.SPREADSHEET_ID}`);
  } catch (err) {
    console.error('更新Google Sheets失敗');
    console.error(err);
  }
}